define(["app", "marionette", "text!templates/add-new.html", "lib/easing"], function (App, Marionette, AddNewTemplate) {

	var AddNewView = Backbone.Marionette.ItemView.extend({

		className: "view",

		initialize: function () {
		},

		template: function(data){
			return _.template(AddNewTemplate, {"variable": "data"})(data);
		},

		serializeData: function () {
			var data = {
			}

			return data;
		},

		onShow: function () {
			var that = this;
			App.mainView.router.loadContent($("#add-new-template").html())

            $(".go-back").click(function(){
            	App.mainView.back();
            	Backbone.history.navigate("#index", {trigger: true, replace: true});
            	that.remove();
            });

            $("#search-jobs").on("input", function () {
            	that.updateSearch();
            });
            $("#search-jobs").on("focus", function () {
            	that.focusSearch();
            });

            this.initEvents();
		},

		initEvents: function () {
			var that = this;

			var bindTypeEnd = (App.os === "mac" || App.os === "mobile") ? "mouseup" : "touchend";
			var bindTypeStart = (App.os === "mac" || App.os === "mobile") ? "mousedown" : "touchstart";

			$(".add-new a.finish").on(bindTypeEnd, function(e){
				that.submit();
			})
		},

		submit: function () {
			this.model.set("customTitle", $("#custom-title").val());

			this.model.createNew();
		},

		updateSearch: function () {
			var that = this;

			clearTimeout($.data(this, 'searchTimer'));
		    $.data(this, 'searchTimer', setTimeout(function() {
				that.model.search($("#search-jobs").val());
		    }, 200));
		},

		focusSearch: function () {
			var top = $(".search-wrapper").offset().top;

			//set page content
			$(".page-content").css({
				"z-index": "600",
				"position": "relative"
			});

			//set search wrapper
			$(".search-wrapper").css({
				"position": 	"fixed",
				"height": 		"100%",
				"top": 			"0"
			});

			//animate search input
			$(".search-wrapper").css({
				"top": top
			}).animate({
				"top": 0
			}, 500, "easeOutQuad");

			$(".background").animate({"opacity": 1}, 600)

            this.listenTo(this.model, 'change', this.addSearchResults);

		},

		selectSearch: function (e) {
			var that = this;
			this.stopListening(this.model);
			$.ajax({
				url: App.urlRoot + "/grabjob",
				type: "POST",
                data: {
                	id: App.userID, 
                	jobNumber: parseInt(e.attr("data-jobnumber"))
                },
                success: function (data) {
                	that.model.set("isAnonymous", 0);
                	that.model.set("jobName", data.results.jobName);
                	that.model.set("productid", data.results.productid);
                	that.model.set("clientid", data.results.clientid);
                	that.model.set("jobid", e.attr("data-jobid"));
                	that.model.set("jobnumber", e.attr("data-jobnumber"));

                	$("#search-jobs").val(data.results.jobName);

                	that.hideSearch();
                }
            });

		},

		addSearchResults: function () {
			var that = this;

			var items = this.model.get("searchResults");

			$(".search-results").html("")
			for (var i = 0; i < items.length; i ++) {
				$(".search-results").append("<li data-jobid='" + items[i][0] + "' data-jobnumber='" + items[i][1].match(/\d+(\d+|\w+)/) + "'>" + items[i][1] + "</li>")
			}

			var bindTypeEnd = (App.os === "mac" || App.os === "mobile") ? "mouseup" : "touchend";
			$(".search-results li").on(bindTypeEnd, function () {
				that.selectSearch($(this));
			})
		},

		hideSearch: function () {
			$(".page-content").css({
				"z-index": "",
				"position": ""
			});
			
			$(".search-wrapper").css({
				"position": 	"relative",
				"top": 			0,
				"height": 		"auto"
			});
			$(".search-results").remove();

		}
	});

	return AddNewView;

});

